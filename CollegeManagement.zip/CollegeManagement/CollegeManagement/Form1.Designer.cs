﻿namespace CollegeManagement
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.loginbtn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.passwordbox = new System.Windows.Forms.TextBox();
            this.namebox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.management = new System.Windows.Forms.Label();
            this.college = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.aDMISSIONToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.newAdmissionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fEESToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.sTUDENTDETAILSToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teachersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.addTeacheToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitSystemToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.eXITSYSTEMToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.loginbtn);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.passwordbox);
            this.panel1.Controls.Add(this.namebox);
            this.panel1.Location = new System.Drawing.Point(477, 264);
            this.panel1.Margin = new System.Windows.Forms.Padding(9, 54, 3, 2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(443, 305);
            this.panel1.TabIndex = 9;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Elephant", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLight;
            this.label4.Location = new System.Drawing.Point(138, 41);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(129, 35);
            this.label4.TabIndex = 8;
            this.label4.Text = "LOGIN";
            // 
            // loginbtn
            // 
            this.loginbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.loginbtn.Location = new System.Drawing.Point(239, 242);
            this.loginbtn.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.loginbtn.Name = "loginbtn";
            this.loginbtn.Size = new System.Drawing.Size(98, 36);
            this.loginbtn.TabIndex = 7;
            this.loginbtn.Text = "Login";
            this.loginbtn.UseVisualStyleBackColor = true;
            this.loginbtn.Click += new System.EventHandler(this.loginbtn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(60, 177);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(83, 20);
            this.label2.TabIndex = 6;
            this.label2.Text = "Password";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(60, 115);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(86, 20);
            this.label1.TabIndex = 5;
            this.label1.Text = "Username";
            // 
            // passwordbox
            // 
            this.passwordbox.Location = new System.Drawing.Point(190, 172);
            this.passwordbox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.passwordbox.Multiline = true;
            this.passwordbox.Name = "passwordbox";
            this.passwordbox.PasswordChar = '*';
            this.passwordbox.Size = new System.Drawing.Size(208, 28);
            this.passwordbox.TabIndex = 4;
            // 
            // namebox
            // 
            this.namebox.Location = new System.Drawing.Point(190, 115);
            this.namebox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.namebox.Multiline = true;
            this.namebox.Name = "namebox";
            this.namebox.Size = new System.Drawing.Size(208, 28);
            this.namebox.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.label3.Font = new System.Drawing.Font("Monotype Corsiva", 25.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(235, 475);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 52);
            this.label3.TabIndex = 8;
            this.label3.Text = "System";
            // 
            // management
            // 
            this.management.AutoSize = true;
            this.management.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.management.Font = new System.Drawing.Font("Monotype Corsiva", 25.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.management.Location = new System.Drawing.Point(108, 405);
            this.management.Name = "management";
            this.management.Size = new System.Drawing.Size(232, 52);
            this.management.TabIndex = 7;
            this.management.Text = "Management";
            // 
            // college
            // 
            this.college.AutoSize = true;
            this.college.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.college.Font = new System.Drawing.Font("Monotype Corsiva", 25.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.college.Location = new System.Drawing.Point(44, 338);
            this.college.Name = "college";
            this.college.Size = new System.Drawing.Size(135, 52);
            this.college.TabIndex = 6;
            this.college.Text = "College";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aDMISSIONToolStripMenuItem,
            this.fEESToolStripMenuItem,
            this.sTUDENTDETAILSToolStripMenuItem,
            this.teachersToolStripMenuItem,
            this.exitSystemToolStripMenuItem,
            this.eXITSYSTEMToolStripMenuItem1,
            this.exitToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(14);
            this.menuStrip1.Size = new System.Drawing.Size(1086, 56);
            this.menuStrip1.TabIndex = 10;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // aDMISSIONToolStripMenuItem
            // 
            this.aDMISSIONToolStripMenuItem.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("aDMISSIONToolStripMenuItem.BackgroundImage")));
            this.aDMISSIONToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newAdmissionToolStripMenuItem});
            this.aDMISSIONToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("aDMISSIONToolStripMenuItem.Image")));
            this.aDMISSIONToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.aDMISSIONToolStripMenuItem.Name = "aDMISSIONToolStripMenuItem";
            this.aDMISSIONToolStripMenuItem.Size = new System.Drawing.Size(116, 28);
            this.aDMISSIONToolStripMenuItem.Text = "Admission";
            this.aDMISSIONToolStripMenuItem.Click += new System.EventHandler(this.aDMISSIONToolStripMenuItem_Click);
            // 
            // newAdmissionToolStripMenuItem
            // 
            this.newAdmissionToolStripMenuItem.Name = "newAdmissionToolStripMenuItem";
            this.newAdmissionToolStripMenuItem.Size = new System.Drawing.Size(195, 26);
            this.newAdmissionToolStripMenuItem.Text = "New Admission";
            this.newAdmissionToolStripMenuItem.Click += new System.EventHandler(this.newAdmissionToolStripMenuItem_Click);
            // 
            // fEESToolStripMenuItem
            // 
            this.fEESToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("fEESToolStripMenuItem.Image")));
            this.fEESToolStripMenuItem.Name = "fEESToolStripMenuItem";
            this.fEESToolStripMenuItem.Size = new System.Drawing.Size(76, 28);
            this.fEESToolStripMenuItem.Text = "Fees";
            this.fEESToolStripMenuItem.Click += new System.EventHandler(this.fEESToolStripMenuItem_Click);
            // 
            // sTUDENTDETAILSToolStripMenuItem
            // 
            this.sTUDENTDETAILSToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("sTUDENTDETAILSToolStripMenuItem.Image")));
            this.sTUDENTDETAILSToolStripMenuItem.Name = "sTUDENTDETAILSToolStripMenuItem";
            this.sTUDENTDETAILSToolStripMenuItem.Size = new System.Drawing.Size(146, 28);
            this.sTUDENTDETAILSToolStripMenuItem.Text = "Search Student";
            this.sTUDENTDETAILSToolStripMenuItem.Click += new System.EventHandler(this.sTUDENTDETAILSToolStripMenuItem_Click);
            // 
            // teachersToolStripMenuItem
            // 
            this.teachersToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.addTeacheToolStripMenuItem,
            this.searchToolStripMenuItem});
            this.teachersToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("teachersToolStripMenuItem.Image")));
            this.teachersToolStripMenuItem.Name = "teachersToolStripMenuItem";
            this.teachersToolStripMenuItem.Size = new System.Drawing.Size(98, 28);
            this.teachersToolStripMenuItem.Text = "Teacher";
            // 
            // addTeacheToolStripMenuItem
            // 
            this.addTeacheToolStripMenuItem.Name = "addTeacheToolStripMenuItem";
            this.addTeacheToolStripMenuItem.Size = new System.Drawing.Size(219, 26);
            this.addTeacheToolStripMenuItem.Text = "Add Teachers info";
            this.addTeacheToolStripMenuItem.Click += new System.EventHandler(this.addTeacheToolStripMenuItem_Click);
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(219, 26);
            this.searchToolStripMenuItem.Text = " Search And Delete";
            this.searchToolStripMenuItem.Click += new System.EventHandler(this.searchToolStripMenuItem_Click);
            // 
            // exitSystemToolStripMenuItem
            // 
            this.exitSystemToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("exitSystemToolStripMenuItem.Image")));
            this.exitSystemToolStripMenuItem.Name = "exitSystemToolStripMenuItem";
            this.exitSystemToolStripMenuItem.Size = new System.Drawing.Size(160, 28);
            this.exitSystemToolStripMenuItem.Text = "Remove  Student";
            this.exitSystemToolStripMenuItem.Click += new System.EventHandler(this.exitSystemToolStripMenuItem_Click);
            // 
            // eXITSYSTEMToolStripMenuItem1
            // 
            this.eXITSYSTEMToolStripMenuItem1.Image = ((System.Drawing.Image)(resources.GetObject("eXITSYSTEMToolStripMenuItem1.Image")));
            this.eXITSYSTEMToolStripMenuItem1.Name = "eXITSYSTEMToolStripMenuItem1";
            this.eXITSYSTEMToolStripMenuItem1.Size = new System.Drawing.Size(108, 28);
            this.eXITSYSTEMToolStripMenuItem1.Text = "About Us";
            this.eXITSYSTEMToolStripMenuItem1.Click += new System.EventHandler(this.eXITSYSTEMToolStripMenuItem1_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.exitToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("exitToolStripMenuItem.Image")));
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(126, 28);
            this.exitToolStripMenuItem.Text = " Exit System";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1086, 676);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.management);
            this.Controls.Add(this.college);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button loginbtn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox passwordbox;
        private System.Windows.Forms.TextBox namebox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label management;
        private System.Windows.Forms.Label college;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aDMISSIONToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem newAdmissionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fEESToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem sTUDENTDETAILSToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teachersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem addTeacheToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitSystemToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem eXITSYSTEMToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
    }
}

