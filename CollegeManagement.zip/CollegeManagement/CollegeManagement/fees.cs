﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;

namespace CollegeManagement
{
    public partial class fees : Form
    {
        OleDbConnection conn;
        OleDbCommand cmd;
        OleDbDataReader reader;
        OleDbDataAdapter adapter;
        DataTable dt;

        public fees()
        {
            InitializeComponent();

        }
        void Getfee()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\fee.accdb");
            dt = new DataTable();
            adapter = new OleDbDataAdapter("SELECT *FROM fee", conn);
            conn.Open();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void txtRegNumber_TextChanged(object sender, EventArgs e)
        {

            string connectString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\newadmission.accdb";

            string selectString = ("select ID, Name, FName, Gender, DOB, Email, Department, Semester, Duration, Address, Phone from NewAdmission where ID like '%" + textid.Text + "%'");

            using (OleDbConnection conn = new OleDbConnection(connectString))
            {
                conn.Open();
                using (OleDbCommand cmd = new OleDbCommand(selectString, conn))
                {
                    cmd.Parameters.AddWithValue("@id", "%" + textid.Text + "%");
                    using (OleDbDataReader reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string Name = reader.GetString(reader.GetOrdinal("Name"));
                            string FName = reader.GetString(reader.GetOrdinal("FName"));
                            string Duration = reader.GetString(reader.GetOrdinal("Duration"));

                            // Set the label text with the retrieved values
                            txtname.Text = Name;
                            txtfname.Text = FName;
                            txtduration.Text = Duration;
                        }
                        else
                        {
                            Console.WriteLine("No record found for the given ID.");
                        }
                    }
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            textid.Text = "";
            txtname.Text = "";
            txtfname.Text = "";
            txtduration.Text = "";
            txtFees.Text = "";
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                string ID = textid.Text;
                string Name = txtname.Text;
                string FName = txtfname.Text;
                string Duration = txtduration.Text;
                string fee = txtFees.Text;
                using (OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\fee.accdb"))
                {
                    conn.Open();

                    using (OleDbCommand cmd = new OleDbCommand("INSERT INTO fee(ID, Name, FName, Duration, Fee)" +
                          " VALUES (@id, @name, @fname, @duration, @fee)", conn))
                    {
                        cmd.Parameters.AddWithValue("@id", ID);
                        cmd.Parameters.AddWithValue("@name", Name);
                        cmd.Parameters.AddWithValue("@fname", FName);
                        cmd.Parameters.AddWithValue("@duration", Duration);
                        cmd.Parameters.AddWithValue("@fee", fee);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        conn.Close();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Student Fee submitted successfully!");
                        }
                        else
                        {
                            MessageBox.Show("Failed to submit studentFee.");
                        }
                    }
                }

            }
            catch (Exception)
            {
                MessageBox.Show("The Fee Already Enter.");
            }


        }

        private void fees_Load(object sender, EventArgs e)
        {
            Getfee();
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            textid.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtname.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtfname.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtduration.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            txtFees.Text = dataGridView1.CurrentRow.Cells[4].Value.ToString();
        }

        private void delete_Click(object sender, EventArgs e)
        {
            string query = "DELETE FROM fee WHERE ID = @ID";
            cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@id", textid.Text);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Delete the fee Data ");
            Getfee();
        }

        private void txtFees_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\fee.accdb");
            if (conn.State == ConnectionState.Closed)
                conn.Open();
            OleDbCommand cmd = new OleDbCommand("select ID, Name, FName, Duration, Fee from fee where ID like '%" + textBox1.Text + "%'", conn);
            OleDbDataAdapter adapter = new OleDbDataAdapter();
            DataTable dt = new DataTable();
            adapter.SelectCommand = cmd;
            dt.Clear();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void update_Click(object sender, EventArgs e)
        {
          string query = "UPDATE fee " +
         "SET " +
         "Name = @name, " +
         "FName = @fname, " +
          "Duration = @duration, " +
           "Fee = @fee " +
           "WHERE " +
            "ID = @id";
            cmd = new OleDbCommand(query, conn);
            cmd.Parameters.AddWithValue("@name", txtname.Text);
            cmd.Parameters.AddWithValue("@fname", txtfname.Text);
            cmd.Parameters.AddWithValue("@duration", txtduration.Text);
            cmd.Parameters.AddWithValue("@fee", txtFees.Text);
            cmd.Parameters.AddWithValue("@id", textid.Text);
            query = "SELECT COUNT(*) FROM fee WHERE ID = @id";
            OleDbCommand cmdCount = new OleDbCommand(query, conn);
            cmdCount.Parameters.AddWithValue("@id", textid.Text);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            MessageBox.Show("Updated the Student fee  Data Successfully");
            Getfee();
        }
    }
}
