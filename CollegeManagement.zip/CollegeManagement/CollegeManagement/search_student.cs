﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CollegeManagement
{
    public partial class search_student : Form
    {
        OleDbConnection conn;
        OleDbCommand cmd;
        OleDbDataReader reader;
        OleDbDataAdapter adapter;
        DataTable dt;
        public search_student()
        {
            InitializeComponent();
        }
        void Getsearch()
        {
            conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\newadmission.accdb");
            dt = new DataTable();
            adapter = new OleDbDataAdapter("SELECT *FROM NewAdmission", conn);
            conn.Open();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void searchbox_TextChanged(object sender, EventArgs e)
        {
            OleDbConnection conn = new OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=|DataDirectory|\\newadmission.accdb");
            if (conn.State == ConnectionState.Closed)
                conn.Open();
            OleDbCommand cmd = new OleDbCommand("select ID, Name, FName, Gender, DOB, Email, Department, Semester, Duration, Address, Phone from NewAdmission where ID like '%" + searchbox.Text + "%'", conn);
            OleDbDataAdapter adapter = new OleDbDataAdapter();
            DataTable dt = new DataTable();
            adapter.SelectCommand = cmd;
            dt.Clear();
            adapter.Fill(dt);
            dataGridView1.DataSource = dt;
            conn.Close();
        }

        private void search_student_Load(object sender, EventArgs e)
        {
            Getsearch();
        }
    }
}
